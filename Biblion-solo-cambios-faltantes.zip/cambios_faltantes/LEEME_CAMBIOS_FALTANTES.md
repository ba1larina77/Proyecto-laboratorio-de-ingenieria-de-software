# Cambios aplicados sobre la versión testeada

Partiendo de `sprint3-testeado`, se aplicó **solo lo que faltaba**. Lo que tu
compañero ya tenía bien (compras demo con plazo de devolución, Unicentro real,
mapa evaluando carrito completo, autocompletado que busca editorial en todos
los resultados) **se respetó sin tocar**.

Copia cada archivo respetando su ruta.

---

## Lo que se añadió / corrigió

### `src/app/store/ShopContext.tsx`
- **Bloqueo de cancelación** (`cancelOrder`): antes la lógica era al revés
  (solo dejaba cancelar los `preparing`). Ahora **no se puede cancelar** ni en
  `preparing` ni en `transit` (en camino). Los pedidos en camino solo pueden
  **devolverse** una vez entregados.

### `src/app/components/shop/History.tsx`
- Se quitaron los botones "Cancelar pedido" / "Cancelar" (en el detalle y en la
  lista), que aparecían para `preparing`. Ya no se muestran porque ningún
  pedido es cancelable con la nueva regla. Se conserva "Solicitar devolución"
  para los `delivered`.

### `src/app/components/admin/AdminPanel.tsx`
- **Editorial editable cuando viene vacía**: si Google Books no devuelve
  editorial, el campo deja de estar bloqueado y muestra el badge
  "✏️ Completar manualmente" para que el admin la escriba.
  (La búsqueda de editorial entre los 10 resultados ya la tenían bien; no se
  tocó esa parte.)

### `src/app/components/shop/StoreMap.tsx`
- **Marcador violeta** con la ubicación de residencia del usuario
  (`userLocation`).
- La **tienda más cercana** se calcula desde la ubicación del usuario (no desde
  el centro de Pereira) cuando está disponible.
- Nuevo prop `resolveStock` para que la disponibilidad del mapa use EXACTAMENTE
  la misma lógica de stock que la lista del checkout (incluye la simulación
  cuando no hay inventario real configurado). Así mapa y lista coinciden.

### `src/app/components/shop/CheckoutModal.tsx`
- **Geocodificación** de la dirección del usuario (Photon/komoot) → estado
  `userLocation`.
- Se pasa `userLocation` y `resolveStock` al `<StoreMap>`.
- Import de `useEffect` añadido.

### `.env` (raíz)
- Restaurado con la clave de Google Books y placeholders de EmailJS.
  ⚠️ Completar las `VITE_EMAILJS_*` con las credenciales reales.

---

## Nota sobre localStorage
Si al probar las compras de devolución no aparecen actualizadas, borra del
navegador (DevTools → Application → Local Storage) la clave
`biblion_purchases`, o usa "Clear site data".
